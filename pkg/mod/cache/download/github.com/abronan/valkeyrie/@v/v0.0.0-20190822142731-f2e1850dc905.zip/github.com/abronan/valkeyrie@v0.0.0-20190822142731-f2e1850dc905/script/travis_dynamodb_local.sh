#!/bin/bash

curl -L http://dynamodb-local.s3-website-us-west-2.amazonaws.com/dynamodb_local_latest.tar.gz -o dynamodb_local_latest.tar.gz
tar -xzf dynamodb_local_latest.tar.gz
