# fastprinter
FastPrinter supports write values in io.Writer without allocation
