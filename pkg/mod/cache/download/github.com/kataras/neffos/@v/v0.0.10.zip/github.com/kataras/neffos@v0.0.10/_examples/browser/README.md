# Client-side for browser and nodejs

Navigate to <https://github.com/kataras/neffos.js> instead.