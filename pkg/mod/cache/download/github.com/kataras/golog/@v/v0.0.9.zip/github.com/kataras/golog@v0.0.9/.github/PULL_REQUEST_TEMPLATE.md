I'd love to see contributions!!!

Link an [issue](https://github.com/kataras/golog/issues) that your PR tries to solve.